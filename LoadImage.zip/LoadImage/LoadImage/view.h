#ifndef VIEW
#define VIEW
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

class View
{
public:
	View();
	void display(string name, cv::Mat obj); //Fonction affichant l'image apr�s filtrage
private:

};
#endif
