#include "controler.h"

void Controller::applyFiltre(int choice)
{
	int choix2 = 0;
	switch (choice)
	{
	case 1: //Association du chiffre 1 au filtrage
		cout << "------------------FILTRAGE------------------"
			<< "\n1 - Filtre median \n 2 - Filtre gaussien" << endl;
		cin >> choix2;
		if (choix2 == 1)//Association du chiffre 1 au filtre m�dian
			median();
		if (choix2 == 2)//Association du chiffre 2 au filtre gaussien
			gaussien();
		break;

	case 2: //Association du chiffre 2 � la d�rivation
		cout << "------------------DERIVATION------------------" << endl;
		derivation();
		break;

	case 3: //Association du chiffre 3 � la morphologie
		cout << "------------------MORPHOLOGIE------------------" << "\n1 - Dilatation \n 2 - Erosion" << endl;
		cin >> choix2;
		if (choix2 == 1)//Association du chiffre 1 au filtre dilatation
			dilatation();
		if (choix2 == 2)//Association du chiffre 2 au filtre �rosion
			erosion();
		break;
	case 4: //Association du chiffre 4 � la d�tection de contours

		cout << "------------------CONTOURS------------------" << endl;
		canny();
		break;

	case 5: //Association du chiffre 5 � la segmentation
		cout << "------------------SEGMENTATION------------------" << "\n1 - Seuillage \n 2 -Segmentation par croissance de regions"  << endl;
		cin >> choix2;
		if (choix2 == 1)//Association du chiffre 1 au filtre de seuillage
			seuillage();
		if (choix2 == 2)//Association du chiffre 1 au filtre de segmentation
			segmentation();
		break;

	case 6: //Association du chiffre 6 � la fermeture
		cout << "------------------FERMETURE------------------" << endl;
		system("exit");
		break;

	default:
		cout << "------------------ERREUR------------------" << endl;
		system("exit");
		break;
	}
}
