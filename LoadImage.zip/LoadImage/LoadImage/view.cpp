#include "view.h"

View::View()
{
}

void View::display(string name, cv::Mat obj)//Fonction affichant l'image apr�s filtrage
{
	imshow(name, obj); 
	waitKey(0);
}


