//Importation des librairies et fichiers n�cessaaire au bon fonctionnement du programme
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include "modele.h"
#include "view.h"
#include "controler.h"
using namespace cv;
using namespace std;

int main()
{
	int choix; // Initialisation de la variable repr�sentant le choix de l'utilisateur
	cout << "------------------CHARGEMENT D'IMAGE------------------ \n " <<endl;
	cout << "------------------TRAITEMENT------------------ \n" 
		<< "Choisissez une option: \n 1 - Filtrage \n 2 - Derivation \n 3 - Operation de morphologie mathematiques" //Affichage des choix disponible
			<< "\n 4 - Detection de contours \n 5 - Segmentations d'images \n 6 - Quitter\n"<< endl;
	cin >> choix; //Acquisition du choi de l'utilisateur
	Controller sujet; //Cr�ation d'un objet repr�sentant l'utilisateur
	sujet.applyFiltre(choix); //Application du filtre choisi 
}

