#ifndef MODELE_H
# define MODELE_H

# include <string>
# include <iostream>
# include "view.h"
# include <opencv2/opencv.hpp>


using namespace cv;
using namespace std;

class Modele : public View
{
public:
	//Initialisation des fonctions
		Mat load();
		void median();
		void gaussien();
		void derivation();
		void dilatation();
		void erosion();
		void canny();
		void seuillage();
		void segmentation();
};

#endif