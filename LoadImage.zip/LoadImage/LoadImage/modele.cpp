#include "Modele.h"

using namespace cv;


Mat Modele::load() //Fonction chargant la photo originale
{
	Mat img = imread("C:/Users/naofe/Pictures/lena.jpg");
	imshow("Avant", img);
	return img;
}

void Modele::median() //Fonction appliquant le filtre m�dian
{
	Mat src = load();
	Mat dst;
	for (int i = 1; i < 50; i = i + 2)
	{
		medianBlur(src, dst, i);
	}
	View::display("Apr�s", dst);
}

void Modele::gaussien()//Fonction appliquant le filtre gaussien
{
	Mat src = load();
	Mat dst;
	for (int i = 1; i < 50; i = i + 2)
	{
		GaussianBlur(src, dst, Size(i, i), 0, 0);
	}
	View::display("Apr�s", dst);
}

void Modele::derivation()//Fonction appliquant le filtre d�rivation
{
	load();
	Mat image = cv::imread("Lena.jpg", IMREAD_GRAYSCALE);
	cv::waitKey();
	cv::Mat dst;
	cv::Sobel(image, dst, CV_8UC1, 1, 0);
	View::display("Apr�s", dst);
}

void Modele::dilatation()//Fonction appliquant le filtre dilatation
{
	Mat src = load(), erosion_dst, dilation_dst;
	int dilation_elem = 2;
	int dilation_size = 10;
	int dilation_type = 4;
	if (dilation_elem == 0) { dilation_type = MORPH_RECT; }
	else if (dilation_elem == 1) { dilation_type = MORPH_CROSS; }
	else if (dilation_elem == 2) { dilation_type = MORPH_ELLIPSE; }
	Mat element = getStructuringElement(dilation_type,
		Size(2 * dilation_size + 1, 2 * dilation_size + 1),
		Point(dilation_size, dilation_size));
	dilate(src, dilation_dst, element);
	View::display("Apr�s", dilation_dst);
}

void Modele::erosion()//Fonction appliquant le filtre erosion
{
	load();
	Mat dst, src = cv::imread("Lena.jpg", IMREAD_GRAYSCALE);
	int erosion_type;
	int erosion_elem = 1;
	int erosion_size = 5;
	if (erosion_elem == 0) { erosion_type = MORPH_RECT; }
	else if (erosion_elem == 1) { erosion_type = MORPH_CROSS; }
	else if (erosion_elem == 2) { erosion_type = MORPH_ELLIPSE; }

	Mat element = getStructuringElement(erosion_type,
		Size(2 * erosion_size + 1, 2 * erosion_size + 1),
		Point(erosion_size, erosion_size));
	/// Apply the erosion operation
	erode(src, dst, element);
	View::display("Apr�s", dst);
}

void Modele::canny()//Fonction r�alisant la d�tection de contours
{
	load();
	Mat src1 = imread("Lena.jpg");
	namedWindow("Original image");
	Mat gray, edge, draw;
	cvtColor(src1, gray, COLOR_BGR2GRAY);

	Canny(gray, edge, 50, 150, 3);

	edge.convertTo(draw, CV_8U);
	namedWindow("image");
	View::display("Apr�s", draw);
}

void Modele::seuillage()//Fonction appliquant le seuillage
{
	load();
	Mat src = imread("Lena.jpg") ; 
	Mat dst;
	double thresh = 0;
	double maxValue = 255;
	threshold(src, dst, thresh, maxValue, THRESH_BINARY);
	waitKey(5000);
	threshold(src, dst, 115, 255, 2);
	imshow("Apr�s", dst);
}

void Modele::segmentation()//Fonction appliquant la segmentation
{
	
}
