#ifndef CONTROLER_H
# define CONTROLER_H
#include <iostream>
#include "modele.h"

class Controller : public Modele
{
public:
	void applyFiltre(int choice); //Fonction pour appliquer le filtre en fonction du choix de l'utilisateur

private:

};
#endif
